import React, { createContext, useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { authAPI } from '../config/api';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [token, setToken] = useState(null);

  // --- Initial Load: CRITICAL FIX FOR STALE STATE ---
  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    const storedUser = localStorage.getItem('user');
    
    let loadedUser = null;
    let loadedToken = null;

    if (storedToken && storedUser) {
      try {
        loadedUser = JSON.parse(storedUser);
        
        // Final validation: check if the parsed user object has the required ID
        if (loadedUser && loadedUser.user_id) {
          loadedToken = storedToken;
        } else {
          // Data corruption detected: treat as logged out
          console.warn("Stored user data was corrupt, clearing session.");
          localStorage.removeItem('user');
          localStorage.removeItem('token');
        }
      } catch (error) {
        // Parsing failed: treat as logged out
        console.error('Error parsing stored user or token:', error);
        localStorage.removeItem('user');
        localStorage.removeItem('token');
      }
    }
    
    // Set the state based on the outcome of the strict validation
    setToken(loadedToken);
    setUser(loadedUser);
    
    // Auth check is complete
    setLoading(false); 
  }, []); // Run only once on mount

  // Register function - remains the same
  const register = async (email, password, role = 'Developer') => {
    try {
      const response = await authAPI.register(email, password, role);
      return response;
    } catch (error) {
      throw error;
    }
  };

  // Login function - integrated with Flask backend using authAPI (Axios)
  const login = async (email, password) => {
    try {
      const response = await authAPI.login(email, password);
      
      const newToken = response.token;
      const newUser = {
        user_id: response.user_id,
        email: response.email,
        role: response.role,
      };

      // CRITICAL WRITE ACTIONS
      localStorage.setItem('token', newToken);
      localStorage.setItem('user', JSON.stringify(newUser));
      
      // Update state
      setToken(newToken);
      setUser(newUser);
      
      return response;
    } catch (error) {
      throw error;
    }
  };

  // Logout function - integrated with Flask backend
  // Logout function - now uses authAPI
  const logout = async () => {
    try {
        // Call the API via axios (optional, but good practice)
        await authAPI.logout();
    } catch (error) {
        console.warn('Logout API call failed, proceeding with local logout:', error);
    } finally {
        // CRITICAL STEP: Clear client state and storage
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        
        setToken(null);
        setUser(null);
        
        // Redirect to login page
        navigate('/login');
    }
  };

  // Check if user is authenticated (relies on both state variables being set)
  const isAuthenticated = () => {
    return !!token && !!user;
  };

  // Get user role
  const getUserRole = () => {
    return user?.role || null;
  };

  const value = {
    user,
    token,
    loading,
    register,
    login,
    logout,
    isAuthenticated,
    getUserRole,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};