const express = require('express');
const ChangeRequest = require('../models/ChangeRequest');
const authMiddleware = require('../middleware/authMiddleware'); // Import standard auth
const roleAuth = require('../middleware/roleAuth'); // <-- 1. IMPORT NEW MIDDLEWARE
const router = express.Router();

// Helper function for SE-7 (This is correct)
async function generateCrNumber() {
  const year = new Date().getFullYear();
  const count = await ChangeRequest.countDocuments({ cr_number: new RegExp(`^CR-${year}`) });
  const nextId = (count + 1).toString().padStart(4, '0');
  return `CR-${year}-${nextId}`; // Format: CR-YYYY-XXXX
}

// --- POST /api/change-requests (SE-8: Submit Draft) ---
// We now apply both middlewares.
// 1. authMiddleware: Checks if user is logged in.
// 2. roleAuth(['Developer']): Checks if user role is 'Developer'
router.post(
  '/', 
  [authMiddleware, roleAuth(['Developer'])],  // <-- 2. APPLY ROLEAUTH
  async (req, res) => {
    const { title, description, category, priority, impact_scope, attachments } = req.body;
    
    try {
      const cr_number = await generateCrNumber(); // SE-7
      
      const newCR = new ChangeRequest({
        title,
        description,
        category,
        priority,
        impact_scope,
        attachments: attachments ? [attachments] : [],
        cr_number,
        createdBy: req.user.id, // From authMiddleware
        status: 'Draft' // SE-8: "Saved with status Draft"
      });
      
      await newCR.save();
      
      // SE-8: "201 response with CR ID"
      res.status(201).json(newCR); 
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to create change request' });
    }
  }
);

// --- GET /api/change-requests (SE-9: View My CRs) ---
// This route is now role-aware based on your matrix
router.get('/', authMiddleware, async (req, res) => {
  try {
    let query = {}; // Default query (gets all)
    const userRole = req.user.role;

    // Developers see "Own only"
    if (userRole === 'Developer') {
      query.createdBy = req.user.id;
    }
    // All other roles (Manager, Lead, QA, etc.) see all CRs
    
    const crs = await ChangeRequest.find(query).sort({ createdAt: -1 });
    res.json({ changeRequests: crs });

  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch change requests' });
  }
});

module.exports = router;